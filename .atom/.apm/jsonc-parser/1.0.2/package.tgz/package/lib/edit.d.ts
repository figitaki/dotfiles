import { Edit, FormattingOptions, JSONPath } from './main';
export declare function removeProperty(text: string, path: JSONPath, formattingOptions: FormattingOptions): Edit[];
export declare function setProperty(text: string, path: JSONPath, value: any, formattingOptions: FormattingOptions, getInsertionIndex?: (properties: string[]) => number): Edit[];
export declare function applyEdit(text: string, edit: Edit): string;
export declare function isWS(text: string, offset: number): boolean;

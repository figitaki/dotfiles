import * as Json from './main';
export declare function format(documentText: string, range: Json.Range | undefined, options: Json.FormattingOptions): Json.Edit[];
export declare function isEOL(text: string, offset: number): boolean;

import * as types from "vscode-languageserver-types";
export interface ILocatedPosition {
    position: types.Position;
    uri: string;
}
export declare namespace LocatedPosition {
    function create(uri: string, position: types.Position): ILocatedPosition;
}
export declare type LocatedRange = types.Location;
export interface ITextDocumentRange {
    range: types.Range;
    textDocument: types.TextDocumentIdentifier;
}
export interface ITextDocumentData {
    content: string;
    languageId: string;
    version: number;
}
export interface IUnformattedTextDocument {
    uri: string;
    languageId: string;
    version: number;
    content: string;
}
export * from "vscode-languageserver-types";

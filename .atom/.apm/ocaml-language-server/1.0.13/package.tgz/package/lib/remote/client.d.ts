import { RequestType } from "vscode-jsonrpc";
import { Location, TextDocumentIdentifier, TextDocumentPositionParams } from "vscode-languageclient";
import * as types from "../types";
export declare const givePrefix: RequestType<TextDocumentPositionParams, string | null, void, void>;
export declare const giveText: RequestType<Location, string, void, void>;
export declare const giveTextDocument: RequestType<TextDocumentIdentifier, types.ITextDocumentData, void, void>;
export declare const giveWordAtPosition: RequestType<types.ILocatedPosition, string, void, void>;

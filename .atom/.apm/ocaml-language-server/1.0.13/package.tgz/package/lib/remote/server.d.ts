import { RequestType } from "vscode-jsonrpc";
import { TextDocumentIdentifier } from "vscode-languageserver-types";
import { IColumnLine } from "../merlin/ordinal";
import * as types from "../types";
export declare const giveCaseAnalysis: RequestType<types.ITextDocumentRange, [{
    end: IColumnLine;
    start: IColumnLine;
}, string] | null, void, void>;
export declare const giveMerlinFiles: RequestType<TextDocumentIdentifier, string[], void, void>;
export declare const giveFormatted: RequestType<types.IUnformattedTextDocument, string | null, void, void>;

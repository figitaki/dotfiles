import * as types from "vscode-languageserver-types";
export interface IColumnLine {
    col: number;
    line: number;
}
export declare type Position = "start" | "end" | number | IColumnLine;
export declare namespace Position {
    function fromCode({character: col, line}: types.Position): IColumnLine;
    function intoCode({col: character, line}: IColumnLine): types.Position;
}
export interface ILocation {
    start: IColumnLine;
    end: IColumnLine;
}
export declare namespace Location {
    function fromCode(range: types.Range): ILocation;
    function intoCode(location: ILocation): types.Range;
}

import * as server from "vscode-languageserver";
export declare class Task {
    readonly task: any;
    readonly token: server.CancellationToken | null;
    constructor(task: any, token?: server.CancellationToken | null);
}

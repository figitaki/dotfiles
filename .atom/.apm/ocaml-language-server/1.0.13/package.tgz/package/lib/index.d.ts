import * as merlin from "./merlin";
import * as parser from "./parser";
import * as remote from "./remote";
import * as types from "./types";
import * as virtual from "./virtual";
export interface ISettings {
    reason: {
        codelens: {
            enabled: boolean;
            unicode: boolean;
        };
        debounce: {
            linter: number;
        };
        diagnostics: {
            tools: Array<"merlin" | "bsb">;
        };
        path: {
            bsb: string;
            ocamlfind: string;
            ocamlmerlin: string;
            opam: string;
            rebuild: string;
            refmt: string;
            refmterr: string;
            rtop: string;
        };
        server: {
            languages: Array<"ocaml" | "reason">;
        };
    };
}
export declare namespace ISettings {
    const defaults: ISettings;
}
export { merlin, parser, remote, types, virtual };

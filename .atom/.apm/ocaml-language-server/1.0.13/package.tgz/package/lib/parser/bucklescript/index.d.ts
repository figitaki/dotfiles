import { types } from "../../../lib";
export declare function parseErrors(bsbOutput: string): {
    [key: string]: types.Diagnostic[];
};

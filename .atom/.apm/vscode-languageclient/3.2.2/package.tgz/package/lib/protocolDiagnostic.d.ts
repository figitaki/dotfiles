import * as code from 'vscode';
export default class ProtocolDiagnostic extends code.Diagnostic {
    data: any;
    constructor(range: code.Range, message: string, severity?: code.DiagnosticSeverity);
}

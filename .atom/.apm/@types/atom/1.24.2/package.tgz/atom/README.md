# Installation
> `npm install --save @types/atom`

# Summary
This package contains type definitions for Atom (https://github.com/atom/atom).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/atom

Additional Details
 * Last updated: Tue, 06 Mar 2018 00:06:55 GMT
 * Dependencies: fs, child_process, jquery, node
 * Global values: none

# Credits
These definitions were written by GlenCFL <https://github.com/GlenCFL>, smhxx <https://github.com/smhxx>, lierdakil <https://github.com/lierdakil>.

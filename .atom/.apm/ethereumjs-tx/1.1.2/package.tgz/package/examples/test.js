var Transaction = require('../index.js')

// create a blank transaction
var tx = new Transaction()
var s = tx.serialize()
console.log(s.toString('hex'))

var privKey = new Buffer('e331b6d69882b4cb4ea581d88e0b604039a3de5967688d3dcffdd2270c0fd109', 'hex')
var txCopy = new Transaction(s)
txCopy.sign(new Buffer(privKey, 'hex'))
console.log(txCopy.serialize().toString('hex'))

parent_diff = 0x83c50442e932a5dc
parent_timestamp = 0x7fd000e2d9055ed6
block_timestamp = 0x7fd000e2d9055ee0
block_number = 0x01

print(1 - (block_timestamp - parent_timestamp) // 10)
print(max(1 - (block_timestamp - parent_timestamp) // 10, -99))

block_diff = parent_diff + parent_diff // 2048 * max(1 - (block_timestamp - parent_timestamp) // 10, -99) + int(2**((block_number // 100000) - 2))

print(block_diff)
